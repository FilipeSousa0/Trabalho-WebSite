$(document).ready(function(e) {
    $('img[usemap]').rwdImageMaps(); 
//Allows imagemaps to be used in a responsive design 
// by recalculating the area coordinates 
// to match the actual image size on load and window.resize
});

function showDialog(text1, text2, text3 = "", text4 = "", img = "") {
  document.querySelector("#imgDialog").src = img;
  document.querySelector('#txtDialog1').textContent = text1;
  document.querySelector('#txtDialog2').textContent = text2;
  document.querySelector('#txtDialog3').textContent = text3;
  document.querySelector('#txtDialog4').textContent = text4;
  document.querySelector("#dlgIntro").showModal();
}


showDialog('Bem-vindo ao nosso escape room sobre o Alzheimer!', 
        'Clica no Sr António para conheceres a sua história e ajuda - o a lembrar-se da sua família!',
        img = "/img/sd1.jpg");

document.querySelector("#btnClosedlgContent").addEventListener("click", function () {
    document.querySelector("#dlgContent").close();
});

function abrirJogoMemoria() {
  const dialog = document.getElementById('dlgMemoria');
  const gameBoard = document.getElementById('gameBoard');
  const gameMessage = document.getElementById('gameMessage');
  gameBoard.innerHTML = '';
  gameMessage.textContent = '';

  const totalCards = 12;
  const personPosition = Math.floor(Math.random() * totalCards); // só um card correto
  let encontrou = false;

  for (let i = 0; i < totalCards; i++) {
    const btn = document.createElement('button');
    const img = document.createElement('img');
    img.src = "silhueta.png";
    img.dataset.index = i;
    btn.appendChild(img);

    btn.addEventListener('click', function () {
      if (encontrou) return;

      const isPerson = (i === personPosition);
      img.src = isPerson ? "Pessoa.png" : "erro.png"; // erro.png = imagem de erro ou continuar silhueta

      if (isPerson) {
        encontrou = true;
        gameMessage.textContent = "🎉 Parabéns! Encontraste a pessoa!";
      } else {
        gameMessage.textContent = "❌ Esta não é a pessoa certa. Tenta outra.";
        setTimeout(() => {
          img.src = "silhueta.png";
        }, 1000);
      }
    });

    gameBoard.appendChild(btn);
  }

  dialog.showModal();
}



