    document.getElementById('contactForm').addEventListener('submit', function(event) {
      event.preventDefault(); // Impede o envio tradicional

      // Captura os valores do formulário
      const nome = document.getElementById('nome').value;
      const email = document.getElementById('email').value;
      const assunto = document.getElementById('assunto').value;
      const mensagem = document.getElementById('mensagem').value;

      // Cria um objeto com os dados
      const dados = {
        nome,
        email,
        assunto,
        mensagem,
        data: new Date().toISOString()
      };

      // Guarda no Local Storage
      let mensagensGuardadas = JSON.parse(localStorage.getItem('mensagens')) || [];
      mensagensGuardadas.push(dados);
      localStorage.setItem('mensagens', JSON.stringify(mensagensGuardadas));

      // Limpa o formulário e avisa o utilizador
      this.reset();
      alert("Mensagem guardada com sucesso (localmente no navegador).");
    });