// chatbot.js
function sendMessage() {
  const input = document.getElementById('userInput');
  const userText = input.value.trim();
  if (userText === "") return;

  appendMessage(userText, 'user');

  const response = getBotResponse(userText.toLowerCase());
  setTimeout(() => appendMessage(response, 'bot'), 500);

  input.value = '';
}

function appendMessage(text, sender) {
  const messageElem = document.createElement('div');
  messageElem.className = sender === 'bot' ? 'bot-message' : 'user-message';
  messageElem.textContent = text;
  document.getElementById('chatbox').appendChild(messageElem);
  document.getElementById('chatbox').scrollTop = document.getElementById('chatbox').scrollHeight;
}

function getBotResponse(input) {
  if (input.includes("marcar consulta")) {
    return "Você pode marcar uma consulta através do nosso portal ou pelo app. Deseja o link?";
  } else if (input.includes("covid") || input.includes("vacina")) {
    return "Para informações atualizadas sobre COVID-19 e vacinas, consulte o site do Ministério da Saúde.";
  } else if (input.includes("alimentação") || input.includes("dieta")) {
    return "Uma alimentação equilibrada inclui frutas, legumes, proteínas e pouca gordura saturada. Quer dicas práticas?";
  } else if (input.includes("exercício")) {
    return "Recomenda-se pelo menos 150 minutos de atividade física moderada por semana.";
  } else if (input.includes("tecnologia") || input.includes("app")) {
    return "Estamos integrando novas tecnologias como telemedicina, wearables e IA para melhorar sua saúde!";
  } else {
    return "Desculpe, não entendi. Pode reformular ou perguntar algo sobre saúde, tecnologia ou consultas?";
  }
}
