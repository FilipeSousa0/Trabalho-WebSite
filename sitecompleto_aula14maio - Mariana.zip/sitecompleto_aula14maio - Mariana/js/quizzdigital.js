function iniciarQuiz() {
  document.getElementById('start-screen').style.display = 'none';
  document.getElementById('quiz').style.display = 'block';
  mostrarPergunta();
}

 const perguntas = [
    {
      pergunta: "1. O que é Saúde Digital?",
      opcoes: ["Medicina alternativa", "Integração de tecnologia e saúde", "Desporto", "Nutrição"],
      correta: 1
    },
    {
      pergunta: "2. Qual destas é uma aplicação comum da Saúde Digital?",
      opcoes: ["Telemedicina", "Bicicletas elétricas", "Rádio AM", "Turismo rural"],
      correta: 0
    },
    {
      pergunta: "3. Qual profissão pode beneficiar da Saúde Digital?",
      opcoes: ["Médicos", "Enfermeiros", "Administradores hospitalares", "Todas as anteriores"],
      correta: 3
    },
    {
      pergunta: "4. O que é um wearable?",
      opcoes: ["Um robô cirúrgico", "Um software médico", "Um dispositivo vestível que monitoriza saúde", "Uma vacina digital"],
      correta: 2
    },
    {
      pergunta: "5. Blockchain em saúde serve para...",
      opcoes: ["Gravar dados médicos com segurança", "Enviar emails", "Criar websites", "Fazer raio-X"],
      correta: 0
    }
  ];

  let indiceAtual = 0;
  let pontuacao = 0;

  function mostrarPergunta() {
    const q = perguntas[indiceAtual];
    const quizDiv = document.getElementById('quiz');
    quizDiv.innerHTML = `
      <div class="question">${q.pergunta}</div>
      <div class="options">
        ${q.opcoes.map((opcao, i) =>
          `<button onclick="verificarResposta(${i})">${opcao}</button>`
        ).join('')}
      </div>
    `;
  }

  function verificarResposta(resposta) {
    const q = perguntas[indiceAtual];
    const correto = resposta === q.correta;
    const quizDiv = document.getElementById('quiz');

    if (correto) {
      pontuacao += 10;
      quizDiv.innerHTML += `<p style="color: green;"><strong>✅ Correto! +10 pontos 🎉</strong></p>`;
    } else {
      quizDiv.innerHTML += `
        <p style="color: red;"><strong>❌ Errado! A resposta certa era: "${q.opcoes[q.correta]}"</strong></p>
      `;
    }

    setTimeout(() => {
      indiceAtual++;
      if (indiceAtual < perguntas.length) {
        mostrarPergunta();
      } else {
        mostrarResultado();
      }
    }, 2000); // Espera 2 segundos antes de avançar
  }

  function mostrarResultado() {
    const quizDiv = document.getElementById('quiz');
    const resultDiv = document.getElementById('result');
    quizDiv.innerHTML = "";

    let emoji = "🧐";
    let feedback = "Boa tentativa!";
    if (pontuacao === 50) {
      emoji = "🏆";
      feedback = "Excelente! Dominaste a Saúde Digital!";
    } else if (pontuacao >= 30) {
      emoji = "👏";
      feedback = "Muito bem! Estás no bom caminho!";
    }

    resultDiv.innerHTML = `
      <p class="emoji">${emoji}</p>
      <p>${feedback}</p>
      <p>Pontuação final: <strong>${pontuacao}/50</strong></p>
    `;
  }

  mostrarPergunta();