window.onload = () => {
  const container = document.getElementById("card-container");

  ucs.forEach((uc, index) => {
    const card = document.createElement("div");
    card.className = "uc-card";

    card.innerHTML = `
      <img src="${uc.imagem}" alt="${uc.nome}" class="uc-img">
      <h3>${uc.nome}</h3>
      <p><strong>Período:</strong> ${uc.periodo}</p>
      <p><strong>ECTS:</strong> ${uc.ects}</p>
      <a href="#" class="btn btn-secondary" onclick="abrirModal(${index})">Mais info</a>
    `;

    container.appendChild(card);
  });

  // Modal global
  const modal = document.createElement("div");
  modal.id = "uc-modal";
  modal.style.display = "none";
  modal.innerHTML = `
    <div id="modal-content" class="modal-content">
      <span id="close-modal" style="cursor:pointer; float:right;">&times;</span>
      <h2 id="modal-title"></h2>
      <p id="modal-desc"></p>
    </div>
  `;
  document.body.appendChild(modal);

  document.getElementById("close-modal").onclick = () => {
    document.getElementById("uc-modal").style.display = "none";
  };
};

function abrirModal(index) {
  const uc = ucs[index];
  document.getElementById("modal-title").innerText = uc.nome;
  document.getElementById("modal-desc").innerText = uc.descricao;
  document.getElementById("uc-modal").style.display = "block";
}
