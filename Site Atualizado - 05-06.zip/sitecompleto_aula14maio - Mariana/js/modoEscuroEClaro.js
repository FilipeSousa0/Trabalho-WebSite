const btn = document.getElementById("mudarTema");

  // Aplica o tema guardado se existir
  if (localStorage.getItem("tema") === "escuro") {
    document.body.classList.add("dark-mode");
    btn.textContent = "☀️";
  }

  // Alterna entre claro e escuro
  btn.addEventListener("click", () => {
    const dark = document.body.classList.toggle("dark-mode");
    btn.textContent = dark ? "☀️" : "🌙";
    localStorage.setItem("tema", dark ? "escuro" : "claro");
  });
