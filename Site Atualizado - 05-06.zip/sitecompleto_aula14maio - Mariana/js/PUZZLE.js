  // Garante que a imagem map funciona em mobile
  $(function() {
    $('img[usemap]').rwdImageMaps();
  });

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("btnMemoria").addEventListener("click", abrirJogoMemoria);
    document.getElementById("btnAntonio").addEventListener("click", abrirModalConhecerAntonio);
    document.getElementById("btnCruzadas").addEventListener("click", abrirJogoCruzadas);
    document.getElementById("btnPuzzle").addEventListener("click", abrirPuzzle);
});


function showDialog(text1, text2, text3 = "", text4 = "", img = "") {
  document.querySelector("#imgDialog").src = img;
  document.querySelector('#txtDialog1').textContent = text1;
  document.querySelector('#txtDialog2').innerHTML = text2;
  document.querySelector('#txtDialog3').textContent = text3;
  document.querySelector('#txtDialog4').textContent = text4;

  document.querySelector("#dlgIntro").showModal();
}

showDialog(
  'Bem-vindo ao nosso escape room sobre o Alzheimer!',
  'Clica no <strong>peito do Sr António</strong> para conheceres a sua história e ajudá-lo a lembrar-se da sua família!',
  "", "", '/img/sd1.jpg'
);



 /* ---------- variáveis globais ---------- */
let estado = "inicio";          //  inicio → viu1 → encontrou2 → completo
let idxPrimeira = null;         // onde está a 1.ª Fátima

function abrirJogoMemoria () {
  const modal = document.getElementById("jogoModal");
  const board = document.getElementById("gameBoard");
  const msg   = document.getElementById("message");

  // limpa modal
  board.innerHTML = "";
  msg.textContent = "";
  modal.style.display = "block";
  estado = "inicio";
  idxPrimeira = null;

  // 10 nomes únicos + 2 Fátimas, baralhados
  const nomes = [
    "Ana", "Beatriz", "Carla", "Diana", "Eva",
    "Giselle", "Helena", "Inês", "Joana", "Laura",
    "Fátima", "Fátima"
  ].sort(() => 0.5 - Math.random());

  // cria cartas
  nomes.forEach((nome, idx) => {
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.nome  = nome;   // guarda o nome
    card.dataset.index = idx;    // guarda a posição

    const img = document.createElement("img");
    img.src = "/img/silhueta.jpg";
    card.appendChild(img);

    card.addEventListener("click", () => tratarClique(card));
    board.appendChild(card);
  });
}

/* ---------- lógica do clique ---------- */
function tratarClique (card) {
  const nome = card.dataset.nome;
  const idx  = +card.dataset.index;

  // já terminaste? então ignora cliques
  if (estado === "completo") return;

  /* mostra SEMPRE o nome clicado */
  card.innerHTML = nome;

  // --- se não for Fátima, esconde de novo depois de 1 s ---
  if (nome !== "Fátima") {
    setTimeout(() => {
      if (estado !== "completo") {
        card.innerHTML = "";
        const img = document.createElement("img");
        img.src = "/img/silhueta.jpg";
        card.appendChild(img);
      }
    }, 1000);
    return;
  }

  // ---------- tratamento especial para Fátimas ----------
  if (estado === "inicio") {
    // 1.ª Fátima encontrada
    idxPrimeira = idx;
    estado = "viu1";
    // esconde-a ao fim de 2 s se ainda não terminou
    setTimeout(() => {
      if (estado === "viu1") {
        card.innerHTML = "";
        const img = document.createElement("img");
        img.src = "/img/silhueta.jpg";
        card.appendChild(img);
        estado = "inicio";
        idxPrimeira = null;
      }
    }, 2000);
    return;
  }

  if (estado === "viu1" && idx !== idxPrimeira) {
    // 2.ª Fátima (diferente posição)
    estado = "encontrou2";
    document.getElementById("message").textContent =
      "Agora clica novamente na primeira Fátima.";
    return;
  }

  if (estado === "encontrou2" && idx === idxPrimeira) {
    // clicou de novo na 1.ª Fátima → ganhou
    estado = "completo";
    document.getElementById("message").innerHTML =
      "🎉 <strong>Parabéns!</strong> Descobriste o nome da mulher do Sr António! <strong>Agora clica no jogo das palavras cruzadas </strong> ";
  }
}

/* botão FECHAR do modal */
document.getElementById("btnClose").addEventListener("click", () => {
  document.getElementById("jogoModal").style.display = "none";
});

function abrirModalConhecerAntonio () {
  document.getElementById('modalConhecerAntonio').showModal();
}
document.getElementById('fecharModalConhecer')
        .onclick = () => document.getElementById('modalConhecerAntonio').close();

/* expõe para o <area onclick="…"> */
window.abrirModalConhecerAntonio = abrirModalConhecerAntonio;

/* abrir jogo */

defer>
/* activa plugin depois de imagens carregarem */
$(function(){ $('img[usemap]').rwdImageMaps(); });


function abrirJogoCruzadas(){
  const dlg=document.getElementById('dlgCruzadas');
  const grid=document.getElementById('grid');
  const msg =document.getElementById('msg');
  grid.innerHTML=""; msg.textContent="";

  const letras=[
    ['J','A','Z','Q','A','J','R'],
    ['M','A','R','I','A','O','T'],   // MARIA
    ['B','E','T','X','C','A','Y'],
    ['J','O','A','L','K','O','Z'],   
    ['P','D','F','M','N','B','O'],
    ['O','G','V','W','K','B','P'],
    ['S','X','Y','Z','L','M','N']
  ];                    // JOAO
  const palavras={
    MARIA:['1-0','1-1','1-2','1-3','1-4'],
    JOAO :['0-5','1-5','2-5','3-5']
  };
  const found={MARIA:false,JOAO:false};

  letras.forEach((lin,r)=>{
    lin.forEach((letra,c)=>{
      const div=document.createElement('div');
      div.className='cell';div.textContent=letra;div.dataset.pos=`${r}-${c}`;
      div.onclick=()=>clicar(div);
      grid.appendChild(div);
    });
    grid.appendChild(document.createElement('br'));
  });
  dlg.showModal();

  function clicar(cell){
    if(cell.classList.contains('found')||cell.classList.contains('selected'))return;
    cell.classList.add('selected');

    Object.entries(palavras).forEach(([nome,coords])=>{
      if(found[nome])return;
      const ok=coords.every(p=>grid.querySelector(`[data-pos="${p}"]`).classList.contains('selected'));
      if(ok){
        coords.forEach(p=>{
          const c=grid.querySelector(`[data-pos="${p}"]`);
          c.classList.remove('selected');c.classList.add('found');
        });
        found[nome]=true; msg.textContent=`✅ Encontraste ${nome}!`;
      }
    });
    if(found.MARIA&&found.JOAO){
      msg.innerHTML = `🎉 <strong>Parabéns!</strong> 
<span style="color:#D2B0FF; font-weight:bold;">MARIA</span> e 
<span style="color:#99B6DB; font-weight:bold;">JOÃO</span> encontrados! 
Agora <strong>clica na peça de puzzle ao lado direito do jogo da Memória</strong>.`;
    }
  }
}

function fecharCruzadas () {
  document.getElementById("dlgCruzadas").close();
}

window.abrirJogoCruzadas=abrirJogoCruzadas;

function abrirPuzzle() {
  document.getElementById('dlgPuzzle').showModal();
  resetPuzzle();
}

function resetPuzzle() {
  const pieces = document.querySelectorAll('.piece');
  const slots = document.querySelectorAll('.slot');
  const container = document.querySelector('.pieces');

  slots.forEach(slot => {
    while (slot.firstChild) {
      container.appendChild(slot.firstChild);
    }
  });

  document.getElementById('puzzleMessage').textContent = "";
}

const pieces = document.querySelectorAll('.piece');
const slots = document.querySelectorAll('.slot');
const message = document.getElementById('puzzleMessage');

pieces.forEach(piece => {
  piece.addEventListener('dragstart', e => {
    e.dataTransfer.setData('text/plain', piece.dataset.name);
  });
});

slots.forEach(slot => {
  slot.addEventListener('dragover', e => e.preventDefault());

  slot.addEventListener('drop', e => {
    e.preventDefault();
    const draggedName = e.dataTransfer.getData('text/plain');
    const draggedPiece = document.querySelector(`.piece[data-name="${draggedName}"]`);

    if (!slot.hasChildNodes()) {
      slot.appendChild(draggedPiece);
      checkPuzzle();
    }
  });
});

function checkPuzzle() {
  const filledCorrectly = Array.from(slots).every(slot => {
    const piece = slot.querySelector('.piece');
    return piece && piece.dataset.name === slot.dataset.target;
  });

  if (filledCorrectly) {
    message.textContent = "🎉 Parabéns! O Sr. António lembrou-se da família!";
    message.style.color = "green";
  } else {
    message.textContent = "";
  }
}



  // 👉 Troca a imagem
  const imagem = document.getElementById("imgPrincipal");
  imagem.src = "/img/imagemEscapeRoomContente.png";  // Caminho da nova imagem

