class UnidadeCurricular {
  constructor(nome, periodo, ects, imagem, descricao) {
    this.nome = nome;
    this.periodo = periodo;
    this.ects = ects;
    this.imagem = imagem;
    this.descricao = descricao;
  }
}

const ucs = [
  new UnidadeCurricular("BASES DA NEUROCIÊNCIA FUNCIONAL", "1º Semestre", 5.5, "/img/neuro.jpg", "Estudo do funcionamento do sistema nervoso e suas aplicações na reabilitação."),
  new UnidadeCurricular("CONCEPÇÃO E PRODUÇÃO MULTIMÉDIA", "1º Semestre", 5.0, "/img/multimedia.jpg", "Criação e produção de conteúdos multimédia para saúde digital."),
  new UnidadeCurricular("DESIGN DE INTERFACES", "1º Semestre", 5.0, "/img/interfaces.jpg", "Desenvolvimento de interfaces intuitivas para aplicações em saúde."),
  new UnidadeCurricular("LAB. DE REABILITAÇÃO E SAÚDE DIGITAL III", "1º Semestre", 4.0, "/img/lab3.jpg", "Aplicação de práticas laboratoriais para soluções digitais."),
  new UnidadeCurricular("TEC. DIGITAIS NA SAÚDE E REABILITAÇÃO I", "1º Semestre", 5.5, "/img/tdsr1.jpg", "Uso de tecnologias digitais para suporte à reabilitação."),
  new UnidadeCurricular("TELESSAÚDE", "1º Semestre", 5.0, "/img/telessaude.jpg", "Estudo da prestação de serviços de saúde à distância."),
  new UnidadeCurricular("ANÁLISE E VISUALIZAÇÃO DE DADOS EM SAÚDE", "2º Semestre", 5.0, "/img/visualizacao.jpg", "Técnicas para análise e visualização de dados clínicos."),
  new UnidadeCurricular("GAMIFICAÇÃO EM SAÚDE E REABILITAÇÃO", "2º Semestre", 5.0, "/img/gamificacao.jpg", "Uso de jogos e dinâmicas lúdicas na saúde e reabilitação."),
  new UnidadeCurricular("LAB. DE REABILITAÇÃO E SAÚDE DIGITAL IV", "2º Semestre", 4.0, "/img/lab4.jpg", "Continuação prática de desenvolvimento de soluções digitais."),
  new UnidadeCurricular("SISTEMAS IMERSIVOS E SIMULAÇÃO", "2º Semestre", 5.5, "/img/simulacao.jpg", "Aplicação de RV e RA na simulação em saúde."),
  new UnidadeCurricular("TEC. DIGITAIS NA SAÚDE E REABILITAÇÃO II", "2º Semestre", 5.5, "/img/tdsr2.jpg", "Continuação no uso de tecnologias digitais na saúde."),
  new UnidadeCurricular("TECNOLOGIAS MÓVEIS APLICADAS À SAÚDE", "2º Semestre", 5.0, "/img/moveis.jpg", "Desenvolvimento de apps móveis e wearables para saúde."),
];
