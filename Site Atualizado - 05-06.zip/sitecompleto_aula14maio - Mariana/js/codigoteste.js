$(document).ready(function(e) {
    $('img[usemap]').rwdImageMaps(); 
//Allows imagemaps to be used in a responsive design 
// by recalculating the area coordinates 
// to match the actual image size on load and window.resize
});

function showDialog(text1, text2, text3 = "", text4 = "", img = "") {
  document.querySelector("#imgDialog").src = img;
  document.querySelector('#txtDialog1').textContent = text1;
  document.querySelector('#txtDialog2').textContent = text2;
  document.querySelector('#txtDialog3').textContent = text3;
  document.querySelector('#txtDialog4').textContent = text4;
  document.querySelector("#dlgIntro").showModal();
} 


showDialog('Bem-vindo ao nosso escape room sobre o Alzheimer!', 
        'Clica no Sr António para conheceres a sua história e ajuda - o a lembrar-se da sua família!',
        img = "/img/sd1.jpg");

    const nomes = Array(12).fill("silhueta");
    let posFatimas = [];
    let estado = "inicio";
    let indexPrimeiraFátima = null;

    function abrirJogoMemoria() {
      const board = document.getElementById("gameBoard");
      const msg = document.getElementById("message");
      const modal = document.getElementById("jogoModal");

      board.innerHTML = "";
      msg.textContent = "";
      estado = "inicio";
      indexPrimeiraFátima = null;
      modal.style.display = "block";

      // Sorteia 2 posições únicas para Fátima
      posFatimas = [];
      while (posFatimas.length < 2) {
        let r = Math.floor(Math.random() * 12);
        if (!posFatimas.includes(r)) posFatimas.push(r);
      }

      for (let i = 0; i < 12; i++) {
        const btn = document.createElement("div");
        btn.classList.add("card");
        btn.dataset.index = i;

        const img = document.createElement("img");
        img.src = "/img/silhueta.jpg";
        btn.appendChild(img);

        btn.addEventListener("click", () => {
          if (estado === "completo") return;

          const idx = parseInt(btn.dataset.index);
          const isFatima = posFatimas.includes(idx);

          if (isFatima) {
            btn.innerHTML = "Fátima";

            if (estado === "inicio") {
              indexPrimeiraFátima = idx;
              estado = "viu1";
              setTimeout(() => {
                if (estado !== "completo") {
                  btn.innerHTML = "";
                  const sil = document.createElement("img");
                  sil.src = "silhueta.png";
                  btn.appendChild(sil);
                }
              }, 2000);
            } else if (estado === "viu1" && idx !== indexPrimeiraFátima) {
              estado = "encontrou2";
              document.getElementById("message").textContent = "Agora clica novamente na primeira Fátima.";
            } else if (estado === "encontrou2" && idx === indexPrimeiraFátima) {
              estado = "completo";
              document.getElementById("message").innerHTML = "🎉 <strong>Parabéns!</strong> Encontraste as duas Fátimas!";
            }
          }
        });

        board.appendChild(btn);
      }
    }

    document.getElementById("btnClose").addEventListener("click", () => {
      document.getElementById("jogoModal").style.display = "none";
    });
    