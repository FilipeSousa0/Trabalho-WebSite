class UnidadeCurricular {
  constructor(nome, periodo, ects, imagem, descricao) {
    this.nome = nome;
    this.periodo = periodo;
    this.ects = ects;
    this.imagem = imagem;
    this.descricao = descricao;
  }
}

const ucs = [
  new UnidadeCurricular("COMUNICAÇÃO DIGITAL EM SAÚDE", "1º Semestre", 5.0, "/img/comunicacao.jpg", "Estudo das estratégias e ferramentas digitais aplicadas à comunicação em saúde."),
  new UnidadeCurricular("INTELIGÊNCIA ARTIFICIAL EM SISTEMAS DE SAÚDE", "1º Semestre", 5.5, "/img/ia.jpg", "Aplicações da IA no diagnóstico, prognóstico e suporte à decisão clínica."),
  new UnidadeCurricular("LABORATÓRIO DE INVESTIGAÇÃO EM SAÚDE DIGITAL", "1º Semestre", 4.0, "/img/investigacao.jpg", "Desenvolvimento de competências investigativas na área da saúde digital."),
  new UnidadeCurricular("SENSORES BIOMÉDICOS", "1º Semestre", 5.0, "/img/sensores.jpg", "Exploração dos sensores utilizados em contextos clínicos e de monitorização de saúde."),
  new UnidadeCurricular("TECNOLOGIAS DIGITAIS NA SAÚDE E REABILITAÇÃO III", "1º Semestre", 5.5, "/img/tdsr3.jpg", "Continuação na aplicação de tecnologias emergentes em reabilitação."),
  new UnidadeCurricular("OPÇÃO I - IMAGEM DIGITAL EM SAÚDE", "1º Semestre", 5.0, "/img/imagem.jpg", "Análise e manipulação de imagens clínicas e biomédicas."),
  new UnidadeCurricular("OPÇÃO I - TEC. DIGITAL EM CONTEXTO LABORATORIAL E FARMÁCIA", "1º Semestre", 5.0, "/img/laboratorio.jpg", "Aplicações digitais para ambientes laboratoriais e farmacêuticos."),
  new UnidadeCurricular("OPÇÃO I - TEC. DIGITAL EM SAÚDE E AMBIENTE", "1º Semestre", 5.0, "/img/ambiente.jpg", "Integração de tecnologias digitais na gestão ambiental em saúde."),
  new UnidadeCurricular("OPÇÃO I - TEC. DIGITAL NOS CUIDADOS PALIATIVOS E ONCOLÓGICOS", "1º Semestre", 5.0, "/img/paliativos.jpg", "Uso de tecnologia em cuidados oncológicos e paliativos."),
  new UnidadeCurricular("ESTÁGIO", "2º Semestre", 15.0, "/img/estagio.jpg", "Experiência prática em instituições ou empresas na área da saúde digital."),
  new UnidadeCurricular("SEGURANÇA EM PROTEÇÃO DE DADOS EM SAÚDE", "2º Semestre", 5.0, "/img/seguranca.jpg", "Estudo das normas e boas práticas de proteção de dados na área da saúde."),
  new UnidadeCurricular("TECNOLOGIAS DIGITAIS NA SAÚDE E REABILITAÇÃO IV", "2º Semestre", 5.0, "/img/tdsr4.jpg", "Exploração final de tecnologias aplicadas à reabilitação."),
  new UnidadeCurricular("OPÇÃO II - DESENVOLVIMENTO PESSOAL E PROFISSIONAL", "2º Semestre", 5.0, "/img/pessoal.jpg", "Promoção de competências pessoais e preparação para o mercado."),
  new UnidadeCurricular("OPÇÃO II - INOVAÇÃO E EMPREENDEDORISMO EM SAÚDE DIGITAL", "2º Semestre", 5.0, "/img/inovacao.jpg", "Fomento de ideias e projetos inovadores no setor da saúde."),
  new UnidadeCurricular("OPÇÃO II - MEDIA INTERATIVA EM SAÚDE DIGITAL", "2º Semestre", 5.0, "/img/media.jpg", "Criação de experiências interativas para educação e promoção da saúde."),
  new UnidadeCurricular("OPÇÃO II - PADRÕES E INTEROPERABILIDADE DE DADOS", "2º Semestre", 5.0, "/img/interoperabilidade.jpg", "Normas e protocolos de integração de sistemas de saúde."),
  new UnidadeCurricular("OPÇÃO II - SISTEMAS DE SUPORTE À DECISÃO EM SAÚDE DIGITAL", "2º Semestre", 5.0, "/img/decisao.jpg", "Ferramentas digitais que auxiliam decisões clínicas."),
  new UnidadeCurricular("OPÇÃO II - SOM E IMAGEM EM SISTEMAS INTERATIVOS", "2º Semestre", 5.0, "/img/somimagem.jpg", "Integração de áudio e vídeo em experiências digitais interativas."),
];
