const perguntas = [
  "O que é saúde digital?",
  "O que são wearables?",
  "O que é telemedicina?",
  "É seguro usar apps de saúde?",
  "Como funcionam os dados em saúde digital?"
];

const respostas = [
  "Saúde digital é o uso de tecnologias para melhorar o cuidado com a saúde, entre eles , apps, sensores, IA e telemedicina.",
  "Wearables são dispositivos vestíveis , como relógios ou pulseiras que monitoram sua saúde em tempo real.",
  "Telemedicina permite consultas médicas à distância por vídeo ou apps especializadas.",
  "Sim, desde que use apps certificados e que protejam seus dados pessoais.",
  "Os dados são recolhidos por sensores, apps e dispositivos, e usados para diagnósticos e tratamentos personalizados."
];

function mostrarMenu() {
  let menu = "🤖 Escolha uma pergunta digitando o número:<br><br>";
  perguntas.forEach((pergunta, index) => {
    menu += `${index + 1}. ${pergunta}<br>`;
  });
  appendMessage(menu, "bot", true);
}

function sendMessage() {
  const input = document.getElementById("userInput");
  const userInput = input.value.trim();
  if (!userInput) return;

  appendMessage(`🔢 ${userInput}`, "user");

  const opcao = parseInt(userInput);
  if (!isNaN(opcao) && opcao >= 1 && opcao <= respostas.length) {
    const resposta = respostas[opcao - 1];
    appendMessage(`✅ ${resposta}`, "bot");
  } else {
    appendMessage("❌ Escolha inválida. Digite um número de 1 a 5.", "bot");
  }

  input.value = "";
}

function appendMessage(text, sender, isHTML = false) {
  const msgDiv = document.createElement("div");
  msgDiv.className = sender === "bot" ? "bot-message" : "user-message";
  msgDiv.innerHTML = isHTML ? text : text.replace(/\n/g, "<br>");
  document.getElementById("chatbox").appendChild(msgDiv);
  document.getElementById("chatbox").scrollTop = document.getElementById("chatbox").scrollHeight;
}

// Mostra o menu ao carregar a página
window.onload = mostrarMenu;
