class UnidadeCurricular {
  constructor(nome, periodo, ects, imagem , descricao) {
    this.nome = nome;
    this.periodo = periodo;
    this.ects = ects;
    this.imagem = imagem;
    this.descricao = descricao
  }
}

const ucs = [
  new UnidadeCurricular("ANATOMIA E FISIOLOGIA", "1º Semestre", 5.5, "/img/Anatomia-e-Fisiologia-Humana.webp","Estudo da estrutura do corpo humano e dos seus sistemas, com foco no funcionamento integrado do organismo."),
  new UnidadeCurricular("INTRODUÇÃO À PROGRAMAÇÃO EM SAÚDE DIGITAL", "1º Semestre", 5.5, "/img/programação.jpg","Fundamentos de lógica computacional e programação aplicados ao desenvolvimento de soluções na área da saúde."),
  new UnidadeCurricular("INTRODUÇÃO À SAÚDE DIGITAL", "1º Semestre", 5.0, "/img/sd.jpg","Abordagem aos conceitos, tecnologias e impacto da transformação digital nos sistemas e serviços de saúde."),
  new UnidadeCurricular("LABORATÓRIO DE REABILITAÇÃO E SAÚDE DIGITAL I", "1º Semestre", 4.0, "/img/lab1.jpg","Criar capacidades relativamente à gestão de projeto."),
  new UnidadeCurricular("MATEMÁTICA APLICADA À BIO-INFORMÁTICA", "1º Semestre", 5.0, "/img/matematica.jpg","Aplicação de conceitos matemáticos ao tratamento e análise de dados biológicos e clínicos.","Estudo dos sistemas digitais de gestão de informação em saúde e da sua interoperabilidade."),
  new UnidadeCurricular("SISTEMAS DE INFORMAÇÃO E COMUNICAÇÃO EM SAÚDE", "1º Semestre", 5.0, "/img/sics.jpg","Estudo dos sistemas digitais de gestão de informação em saúde e da sua interoperabilidade."),
  new UnidadeCurricular("CIÊNCIA DE DADOS", "2º Semestre", 5.0, "/img/datascience.webp","Introdução à análise de dados, incluindo técnicas estatísticas e uso de ferramentas para tratamento de informação em saúde."),
  new UnidadeCurricular("DESIGN CENTRADO NO UTILIZADOR", "2º Semestre", 5.0, "/img/dcu.jpg","Desenvolvimento de soluções digitais em saúde com foco nas necessidades e experiência dos utilizadores."),
  new UnidadeCurricular("LABORATÓRIO DE REABILITAÇÃO E SAÚDE DIGITAL II", "2º Semestre", 4.0, "/img/lab2.jpg","Explorar as capacidade de gestão de projeto desenvolvidas no semestre passado."),
  new UnidadeCurricular("PARADIGMAS DA PROGRAMAÇÃO EM SAÚDE DIGITAL", "2º Semestre", 5.0, "/img/paradigmas.jpg","Exploração de diferentes paradigmas de programação e sua aplicação no desenvolvimento de software para saúde."),
  new UnidadeCurricular("PATOLOGIA GERAL", "2º Semestre", 5.5, "/img/patologia.jpg","Estudo dos principais processos patológicos, incluindo causas, desenvolvimento e efeitos das doenças."),
  new UnidadeCurricular("TECNOLOGIAS MULTIMÉDIA EM SAÚDE DIGITAL", "2º Semestre", 5.5, "/img/tecnologia.webp","Criação e aplicação de conteúdos multimédia (áudio, vídeo, animação) para comunicação e educação em saúde."),
];